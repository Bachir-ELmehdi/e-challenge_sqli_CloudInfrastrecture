package testsCloud;

import static org.junit.Assert.assertEquals;

import org.junit.Assert;
import org.junit.Test;

import ma.sqli.CloudInfrastructure.*;
import ma.sqli.Exception.CreateStoreException;
import ma.sqli.Exception.MachineStateException;
/**
 * @author =====> BACHIR ELMEHDI
 * Project =====> CouldInfrastructure
 * Package =====> testsCloud
 * Date    =====> 15 nov. 2019 
 */
public class TestsCloud {
	private CloudInfrastructure cloud = new CloudInfrastructure();
	
	
	@Test
    public void can_create_a_store_in_cloud() {
        cloud.createStore("myFiles");
        cloud.uploadDocument("myFiles", "book.pdf"); // upload "book.pdf" in the "myFiles" store

        String expected = "myFiles:book.pdf";
       // System.out.println(cloud.listStores());
        assertEquals(expected, cloud.listStores()); // make sure the cloud.listStores() method
        // return the expected String
    }
	  @Test
	    public void can_create_multiple_stores_in_cloud() {
	        cloud.createStore("myFiles");
	        cloud.createStore("myImages");
	        cloud.uploadDocument("myImages", "picture.jpeg", "profile.png");
           //  System.out.println(cloud.listStores());
	        String expected = "myFiles:empty||myImages:picture.jpeg, profile.png"; // an empty store is display as "empty"
	        assertEquals(expected, cloud.listStores());
	    }
	  
	  @Test
	    public void can_delete_and_empty_stores_in_cloud() {
	        cloud.createStore("myFiles");
	        cloud.createStore("myImages");
	        cloud.uploadDocument("myImages", "picture.jpeg", "profile.png");

	        cloud.deleteStore("myFiles"); // delete a store
	        assertEquals("myImages:picture.jpeg, profile.png", cloud.listStores());

	        cloud.emptyStore("myImages"); // empty a store
	        assertEquals("myImages:empty", cloud.listStores()); // an empty store is display as "empty"
	    }
	  
	  /**
	     * The creation of a store with a name that is already used will throw the CreateStoreException.
	     */
	    @Test(expected = CreateStoreException.class)
	    public void cannot_create_stores_with_same_names() {
	        cloud.createStore("myFiles");
	        cloud.createStore("myFiles"); // will throw the exception
	    }
	    
	    @Test
	    public void create_machines() {
	        // create a new machine takes 4 parameters : name, operating system, disk size, memory.
	        cloud.createMachine("machine1", "Linux", "50gb", "8gb");
	        cloud.createMachine("machine2", "Windows", "20gb", "4gb");
	        // Remember, all machines are inactive by default.
	         // System.out.println(cloud.listMachines());
	        assertEquals("machine1:inactive||machine2:inactive", cloud.listMachines());
	        

	        cloud.startMachine("machine1"); // start the machine "machine1"
	        assertEquals("machine1:running||machine2:inactive", cloud.listMachines());

	        cloud.startMachine("machine2");
	        cloud.stopMachine("machine1"); // stop machine "machine1"

	        assertEquals("machine1:stopped||machine2:running", cloud.listMachines());
	    }
	    
	    @Test(expected = MachineStateException.class)
	    public void cannot_launch_already_started_machine() {
	        cloud.createMachine("machine1", "Linux", "50gb", "8gb");
	        cloud.startMachine("machine1");
	        assertEquals("machine1:running", cloud.listMachines());

	        cloud.startMachine("machine1"); // will throw the exception
	    }
	    
	    @Test
	    public void can_check_used_disk_and_ram_per_machine() {
	        cloud.createMachine("machine1", "Linux", "50gb", "8gb");
	        assertEquals("machine1:inactive", cloud.listMachines());

	        assertEquals(0, cloud.usedMemory("machine1"), PRECISION); // Only running machines consume memory
	        assertEquals(50, cloud.usedDisk("machine1"), PRECISION); // the disk is always consumed

	        cloud.startMachine("machine1");
	        assertEquals(50, cloud.usedDisk("machine1"), PRECISION);
	        // as the machine is now running, all its memory is used.
	        assertEquals(8, cloud.usedMemory("machine1"), PRECISION);

	        cloud.stopMachine("machine1");
	        assertEquals(50, cloud.usedDisk("machine1"), PRECISION);
	        // The memory will be released as the machine has been stopped
	        assertEquals(0, cloud.usedMemory("machine1"), PRECISION);
	    }
	    
	    @Test
	    public void can_check_used_disk_per_store() {
	        cloud.createStore("myImages");
	        cloud.uploadDocument("myImages", "picture.jpeg");
	        assertEquals("myImages:picture.jpeg", cloud.listStores());

	        // One document exists in "myImages", the used disk should be 0.1gb
	        Assert.assertEquals(0.100, cloud.usedDisk("myImages"), PRECISION);

	        cloud.uploadDocument("myImages", "profile.png");
	        assertEquals("myImages:picture.jpeg, profile.png", cloud.listStores());

	        // 2 documents, used disk = 200mb
	        assertEquals(0.200, cloud.usedDisk("myImages"), PRECISION);
	    }
	    @Test
	    public void can_check_aggregated_data_for_all_machines_and_stores() {
	        cloud.createMachine("machine1", "Linux", "50gb", "8gb");
	        cloud.createMachine("machine2", "Windows", "20gb", "4gb");
	        assertEquals("machine1:inactive||machine2:inactive", cloud.listMachines());

	        // globalUsedDisk method should return the used disk of all machines and stores existing in the cloud, same for globalUsedMemory
	        // for now 2 machines exists, with 50gb and 20gb disk sizes = 70gb
	        
	        assertEquals(70, cloud.globalUsedDisk(), PRECISION);
	        assertEquals(0, cloud.globalUsedMemory(), PRECISION); // machines are inactive, no memory is used
	        

	        cloud.startMachine("machine1");
	        assertEquals(70, cloud.globalUsedDisk(), PRECISION);
	        assertEquals(8, cloud.globalUsedMemory(), PRECISION);


	        cloud.startMachine("machine2");
	        assertEquals(70, cloud.globalUsedDisk(), PRECISION);
	        assertEquals(12, cloud.globalUsedMemory(), PRECISION);
	        
	        cloud.createStore("myImages");
	        cloud.uploadDocument("myImages", "picture.jpeg");
	        assertEquals("myImages:picture.jpeg", cloud.listStores());
            System.out.println(cloud.globalUsedDisk());
	        assertEquals(70.100, cloud.globalUsedDisk(), PRECISION);
	        assertEquals(12, cloud.globalUsedMemory(), PRECISION);

	        cloud.stopMachine("machine1");
	        assertEquals(70.100, cloud.globalUsedDisk(), PRECISION);
	        assertEquals(4, cloud.globalUsedMemory(), PRECISION);

	        cloud.emptyStore("myImages");
	        assertEquals(70, cloud.globalUsedDisk(), PRECISION);
	        assertEquals(4, cloud.globalUsedMemory(), PRECISION);
	    }


	    // Used only to compare double, you can totally ignored it
	    private static final double PRECISION = 0.00001;

}
