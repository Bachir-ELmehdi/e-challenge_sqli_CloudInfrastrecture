package ma.sqli.CloudInfrastructure;

import java.util.Arrays;

import java.util.LinkedList;
import java.util.StringTokenizer;

import ma.sqli.entite.*;
import ma.sqli.Exception.CreateStoreException;
import ma.sqli.Factory.*;
/**
 * @author =====> BACHIR ELMEHDI
 * Project =====> CouldInfrastructure
 * Package =====> sqli.ma.CloudInfrastructure
 * Date    =====> 15 nov. 2019 
 */
public class CloudInfrastructure {
	private LinkedList<Store> stores;
	private LinkedList<Machine> machines;
	private String name;
	private FactoryFile factF;
	private FactoryStore factS;
	private FactoryMachine factM;
	/**
	 * 
	 */
	public CloudInfrastructure() {
		// TODO Auto-generated constructor stub
		stores = new LinkedList<Store>();
		machines = new LinkedList<Machine>();
	    factF = new FactoryFile();
	    factS = new FactoryStore();
	    factM = new FactoryMachine();
	}
	
	public void createStore(String name) {
		Store store = stores.stream().
				filter(x->x.getName().equals(name)).
				findAny().
				orElse(null);
		if(store == null)
		stores.add(factS.getInstance(name));
		else
			throw new CreateStoreException();
	}
	public  void uploadDocument(String nameStore,String ...nameFIle) {
       Store store = chercherStore(nameStore);
       if(store != null) {
    	   Arrays.stream(nameFIle).
    	   forEach(file->stores.get(stores.indexOf(store)).addDocument(factF.getInstance(file)));
       }
	}
	
	public String listStores() {
		//System.out.println(stores.get(0).toString());
		String s = "";
		
		for(int i=0; i<stores.size();i++) {
			 if(stores.size()>1) {
				if(i<stores.size()-1)
		     s+= stores.get(i).toString()+"||";
			else
				s+= stores.get(i).toString();
		
		}else
		{
			s+= stores.get(i).toString();
		}
		}
			
		return s;
	}
	
	public Store chercherStore(String name) {
		Store store = stores.stream().
				filter(x->x.getName().equals(name)).
				findAny().
				orElse(null);
		return store;
	}
	
	/////////////---COTE MACHINE---///////////////////////////////////////////////
	//create Machine
	
	public void createMachine(String name,String system,String disk,String memory) {
		machines.add(factM.getInstance(name, system, disk, memory));
	}
	
	public String  listMachines() {
	String s = "";
		
		for(int i=0; i<machines.size();i++) {
			 if(machines.size()>1) {
				if(i<machines.size()-1)
			        s+= machines.get(i).toString()+"||";
				else
					s+= machines.get(i).toString();
	     	}
			 else
	    	{	s+= machines.get(i).toString();}
		}
		return s;
	}
	
	//start Machine
	public  void  startMachine(String name) {
		Machine a = machines.stream().
				filter(x->x.getName().equals(name)).
				findAny().orElse(null);
	        	 a.startMachine();
	        	// System.out.println(a.toString());
	}
	
	//stopped Machine
	public void  stopMachine(String name) {
		Machine a = machines.stream().
				filter(x->x.getName().equals(name)).
				findAny().orElse(null);
	        	a.stopMachine();

	}
	
	public Machine chercherMachine(String name) {
		Machine a = machines.stream().
				filter(x->x.getName().equals(name)).
				findAny().orElse(null);
		return a;
	}
	//Memory Used by one  machine
	public double  usedMemory(String name) {
		double memory ;
		Machine a = chercherMachine(name);
	     if(a.getState().toString().equals("running")) {
	    		StringTokenizer Dis =  new StringTokenizer(a.getMemory(),  "g");
				memory = Double.parseDouble(Dis.nextToken());
	     }else {
	    	 memory = 0;
	     }
	     return memory;
	}
	public double  usedDisk(String name) {
		 double Disk = 0;
	Machine a = chercherMachine(name);
		if (!(a==null)) { 
			StringTokenizer Dis =  new StringTokenizer(a.getDisk(),  "g");
			Disk = Double.parseDouble(Dis.nextToken());
			
    	}else{
    		Store store = chercherStore(name);
    		Disk = store.getFiles().size()*0.100;
    	}
		return Disk;
	}
	
	//globale StockageDisk utiliser
	public double globalUsedDisk() {
		double diskGlobale = 0;
		for(Machine m :this.machines) {
			diskGlobale+= usedDisk(m.getName());
			
		}				
		
		return diskGlobale+getSizeofstores();
	}
	
	public double  globalUsedMemory() {
		double memoryGlobale=0;
		for(Machine m :this.machines) {
			memoryGlobale+= usedMemory(m.getName());
		}
		return memoryGlobale;
	
	}
	
	public double getSizeofstores() {
		double totale = 0;
		for(Store s :this.stores) {
			if(s.getFiles().isEmpty() == false) {
			totale+= (s.getFiles().size()*0.100);
			}
		}
		return totale;
	}
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	public void deleteStore(String name) {
		Store store =this.chercherStore(name);
		stores.remove(store);
	}
	public void emptyStore( String name) {
		Store store =this.chercherStore(name);
		store.getFiles().clear();
	}

}
