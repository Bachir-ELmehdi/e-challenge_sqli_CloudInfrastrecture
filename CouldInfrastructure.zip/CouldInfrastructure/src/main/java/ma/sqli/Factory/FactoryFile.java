package ma.sqli.Factory;


import ma.sqli.entite.*;
/**
 * @author =====> BACHIR ELMEHDI
 * Project =====> CouldInfrastructure
 * Package =====> ma.sqli.Factory
 * Date    =====> 15 nov. 2019 
 */
public class FactoryFile {
	
	public File getInstance(String name) {
		return new File(name);
	}

}
