package ma.sqli.Factory;

import ma.sqli.entite.*;
/**
 * @author =====> BACHIR ELMEHDI
 * Project =====> CouldInfrastructure
 * Package =====> sqli.ma.Factory
 * Date    =====> 15 nov. 2019 
 */
public class FactoryStore {

	
	public Store getInstance(String name) {
		return new Store(name);
	}
}
