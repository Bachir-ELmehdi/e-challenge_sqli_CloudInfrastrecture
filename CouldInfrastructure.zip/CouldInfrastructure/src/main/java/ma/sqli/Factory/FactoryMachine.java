package ma.sqli.Factory;

import ma.sqli.entite.Machine;

/**
 * @author =====> BACHIR ELMEHDI
 * Project =====> CouldInfrastructure
 * Package =====> ma.sqli.Factory
 * Date    =====> 15 nov. 2019 
 */
public class FactoryMachine {
	
	public Machine getInstance(String name,String system,String disk,String memory)
	{
		return new Machine( name, system, disk, memory);
	}

}
