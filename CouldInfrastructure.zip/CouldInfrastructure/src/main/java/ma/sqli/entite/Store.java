package ma.sqli.entite;

import java.util.LinkedList;

/**
 * @author =====> BACHIR ELMEHDI
 * Project =====> CouldInfrastructure
 * Package =====> ma.sqli.entite
 * Date    =====> 15 nov. 2019 
 */
public class Store {
	private String name;
	private LinkedList <File> files;
	/**
	 * 
	 */
	public Store(String name) {
		// TODO Auto-generated constructor stub
		this.name = name;
		files= new LinkedList<File>();
	}
	
	/**
	 * @return the files
	 */
	public LinkedList<File> getFiles() {
		return files;
	}
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return  name+":"+this.genereChaine();
	}
	
	public String genereChaine() {
		String s="" ;
		if( ! this.files.isEmpty()) {
			for(int i=0; i<files.size();i++) {
				 if(files.size()>1) {
					if(i<files.size()-1)
			     s+= files.get(i).toString()+", ";
				else
					s+= files.get(i).toString();
			
			}else
			{
				s+= files.get(i).toString();
			}}
		}else {
			s= "empty";
		}
		return s;
	}
	public void addDocument(File file) {
		this.files.add(file);
	}
	public void empty() {
		for(int i = 0;i<this.getFiles().size();i++) {
			this.getFiles().remove(this.getFiles().get(i));
		}
	}
	

}
