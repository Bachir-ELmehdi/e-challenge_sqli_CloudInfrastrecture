package ma.sqli.entite;


import ma.sqli.StateMachine.InactiveMachaine;
import ma.sqli.StateMachine.StateMachine;

/**
 * @author =====> BACHIR ELMEHDI
 * Project =====> CouldInfrastructure
 * Package =====> ma.sqli.entite
 * Date    =====> 15 nov. 2019 
 */
public class Machine {
	private String name;
	private String system;
	private String disk;
    private String memory;
    private StateMachine state;
	
	/**
	 * @param state the state to set
	 */
	
	/**
	 * 
	 */
	public Machine() {
		// TODO Auto-generated constructor stub
	}
	public Machine (String name,String system,String disk,String memory) {
		this.name=name;
		this.system = system;
		this.disk = disk;
		this.memory = memory;
		this.state = new InactiveMachaine();
		state.setMachine(this);
	}
	
	
	public void setState(StateMachine state) {
		this.state = state;
		state.setMachine(this);
	}
	
	public void startMachine() {
		state.started();
	}
	public void stopMachine()
	{
		state.stoped();
	}
	/**
	 * @return the state
	 */
	public String  getState() {
		return state.toString();
	}
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return name+":"+state.toString();
	}
	
	/**
	 * @return the disk
	 */
	public String getDisk() {
		return disk;
	}
	/**
	 * @return the memory
	 */
	public String getMemory() {
		return memory;
	}
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @return the system
	 */
	public String getSystem() {
		return system;
	}
	/**
	 * @param disk the disk to set
	 */
	public void setDisk(String disk) {
		this.disk = disk;
	} 
	/**
	 * @param memory the memory to set
	 */
	public void setMemory(String memory) {
		this.memory = memory;
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * @param system the system to set
	 */
	public void setSystem(String system) {
		this.system = system;
	}

}
