package ma.sqli.entite;

/**
 * @author =====> BACHIR ELMEHDI
 * Project =====> CouldInfrastructure
 * Package =====> ma.sqli.entite
 * Date    =====> 15 nov. 2019 
 */
public class File {
	private String name;
	
	/**
	 * 
	 */
	public File(String name) {
		// TODO Auto-generated constructor stub
	this.name = name;
	}

	public File() {
		// TODO Auto-generated constructor stub
	}
	
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return name;
	}

}
