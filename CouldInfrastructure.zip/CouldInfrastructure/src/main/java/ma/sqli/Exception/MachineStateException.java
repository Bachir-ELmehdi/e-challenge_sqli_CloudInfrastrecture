package ma.sqli.Exception;

/**
 * @author =====> BACHIR ELMEHDI
 * Project =====> CouldInfrastructure
 * Package =====> ma.sqli.Exception
 * Date    =====> 15 nov. 2019 
 */
public class MachineStateException  extends RuntimeException{

}
