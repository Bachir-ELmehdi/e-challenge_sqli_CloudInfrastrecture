package ma.sqli.StateMachine;

import ma.sqli.Exception.MachineStateException;

/**
 * @author =====> BACHIR ELMEHDI
 * Project =====> CouldInfrastructure
 * Package =====> ma.sqli.StateMachine
 * Date    =====> 15 nov. 2019 
 */
public class InactiveMachaine  extends StateMachine{

	@Override
	public void started() {
		// TODO Auto-generated method stub
		machine.setState(new Started());
	}

	@Override
	public void stoped() {
		// TODO Auto-generated method stub
		throw new MachineStateException();

	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "inactive";
	}
	

}
