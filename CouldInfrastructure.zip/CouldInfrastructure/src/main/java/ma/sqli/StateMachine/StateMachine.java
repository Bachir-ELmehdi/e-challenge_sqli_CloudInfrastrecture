package ma.sqli.StateMachine;

import ma.sqli.entite.Machine;

/**
 * @author =====> BACHIR ELMEHDI
 * Project =====> CouldInfrastructure
 * Package =====> ma.sqli.StateMachine
 * Date    =====> 15 nov. 2019 
 */
public abstract  class StateMachine {
	public Machine machine;
    public abstract 	void started();
    public  abstract 	void stoped();
    public abstract String toString();
    
    /**
	 * @param machine the machine to set
	 */
	public void setMachine(Machine machine) {
		this.machine = machine;
	}
    
    /**
	 * @return the machine
	 */
	public Machine getMachine() {
		return machine;
	}

}
